package com.example.filmslibrary.ui.dialogs

object DialogConst {
    const val SIGN_UP_STATE = 0
    const val SIGN_IN_STATE = 1
}
