package com.example.filmslibrary.ui.fragmentInterfaces

interface ClickListenerOnDetailsPageFragment {
    fun onLikeClickListener()
    fun onSaveCommentClickListener()
}